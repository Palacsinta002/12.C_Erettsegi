A 14-15 század Nyugat Európában jöttek létre nagyobb városok, telepek, ahol az emberek kereskedtek, ezek folyó torkolatoknál, illetve kereskedelmi csomópontoknál, ahol kereskedő telepek, és kézművesek telepedtek meg. Gyakran a hospesek kereskedők, utazók, vagy éppen mesteremberek voltak, akik ideiglenesen dolgoztak egy városban.

A kommuna-mozgalom a középkori városokban jelent meg, és az ott élő polgárok igyekeztek autonómiát szerezni a helyi uralkodók vagy feudális hatalmak ellen, célja, hogy megvédje a városi lakosság jogait és privilégiumait, valamint növelje a helyi autonómiát és önrendelkezést. Földesúrtól való függés megszüntetése, szabadulás, ez volt a privigélium, azaz különleges jog.

A várost a város fal határolta, sokszor több város fal is, ugyanis egy egy város folyamatosan bővült. A városban jelenvoltak jogok, amelyeket a város gyakoroltathatott, pl. árumegállítójog, vásártartás joga, vámmentesség, szabad piactartás joga.

 A céhek általában azonos utcában éltek, mint pl. kovács utca, ott a kovácsok. A városba való bejutás a város kapun történt. A város negyedekre oszlik, a város élén a bíró áll, vagy más tisztségviselők.

A polgárjoggal nem rendelkezők, azaz a plebejusok is a középkori városok lakosai voltak, ők művelték a polgárok földjeit. A patríciusok polgárok voltak, rendelkeztek jogokkal, gyakran szembenálló felek voltak a plebejusok azért küzdöttek, hogy jogokat kapjanak.

 A város lakói a polgárok voltak, a város közepén a templom állt. Céhek, kis csoportokban állítanak elő kész terméket, drága, azonban jó minőség, élén a mester áll, mesterré válás folyamata: inas-legény-mester, a céhben szigorú szabályzat volt jelen, amely szabályozta a céh tagjainak kötelességeit. Céheknél a versenyt kiküszöbölték, nem volt jelen, céh szabályzata is tiltotta.

A városban jelenvoltak a kontárok akik céhen kívüli mesterek voltak és kész terméket állítottak elő, drága, de jó minőségű, lassú. A városban fölfelé építkeztek, hogy a falon belül maradjanak, az épületeket fából építették, amelyek tűzveszélyesek voltak, a házak között kevés hely volt, sikátoros, tehát zsúfolt volt, és rossz higiénia viszonyok uralkodtak, ez járványokhoz vezetett, pl. Pestis.